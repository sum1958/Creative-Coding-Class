function setup() {
  
  createCanvas(720, 400);
  background(11,11,69);

  // Set colors
  fill(255,193,204);
  stroke(0,0,139);
  
  
  rect(80, 140, 140, 40);
  // An ellipse
  ellipse(340, 340, 90, 90);
  // A triangle
  triangle(400, 100, 320, 100, 310, 80);
  
  fill(255,0,127);
  stroke(0,0,139);

  // A design for a simple flower
  translate(380, 200);
  noStroke();
  for (let i = 0; i < 10; i ++) {
    ellipse(0, 30, 20, 80);
    rotate(PI/5);
  }}
   
  



